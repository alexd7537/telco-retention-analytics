# TELCO / RETAIN

## Análisis de abandono y plan de retención de clientes

Caso de portafolio de Alexander Cordova. **Python · SQLite/SQL · Power BI.**
La pregunta de negocio: ¿dónde se concentra el abandono y qué segmentos conviene investigar con un piloto de retención?

![Resumen editorial del análisis, no captura de Power BI](images/01_resumen_editorial.png)

Diseño editorial: violeta oscuro y lima, titulares serif y navegación superior en Power BI. Las imágenes son exportaciones del resumen ejecutivo, no capturas nativas del dashboard.

### Resultado de esta versión

| Indicador | Resultado |
|---|---:|
| Clientes analizados | 7.043 |
| Abandonos observados | 1.869 |
| Tasa descriptiva de abandono | 26,54 % |
| Activos en la muestra | 5.174 |
| Candidatos activos de los segmentos elegibles | 1.442 |
| Cargos mensuales asociados a abandonos | 139.130,85 UM |

Los contratos mensuales tienen una tasa observada del 42,71 %, frente al 11,27 % de los anuales y el 2,83 % de los bianuales. El segmento mensual de hasta 6 meses presenta un 55,20 % y es el primer candidato para un piloto de bienvenida.

**Interpretación:** asociaciones descriptivas, no efectos causales. UM significa unidad monetaria: el CSV no especifica la moneda. La suma de cargos de quienes abandonaron no es una pérdida contable ni una estimación de ingresos futuros en riesgo.

### Estado de los entregables

| Entregable | Estado |
|---|---|
| Fuente preservada, limpieza y controles | Ejecutados; 7.043 filas conservadas |
| Base SQLite y 11 consultas de análisis | Ejecutadas y conciliadas con Python |
| Notebook educativo | 10 celdas ejecutadas secuencialmente en Python local |
| Segmentos y propuesta de piloto | Generados; no se ha ejecutado ninguna campaña |
| Resumen ejecutivo PDF | 5 páginas renderizadas y revisadas |
| Power BI | PBIP con 3 páginas, 2 tablas y 1 relación; prueba nativa en Desktop pendiente |
| Pruebas automatizadas | 20 comprobaciones aprobadas |
| Modelo predictivo | No incluido; ampliación posterior |

### Empieza aquí

- [Guía para abrir y entender el proyecto](EMPIEZA_AQUI.md).
- [Resumen ejecutivo](reports/Resumen_ejecutivo_retencion.pdf).
- [Notebook con resultados](notebooks/01_exploracion.ipynb).
- [Proyecto editable de Power BI](powerbi/TelcoRetention.pbip).
- [Plan de retención](docs/plan_retencion.md).
- [Metodología](docs/metodologia.md) y [diccionario de datos](docs/diccionario_datos.md).

### Organización

```text
proyecto_2_retencion/
  data/raw/          Copia exacta del CSV aportado; no se transforma
  data/processed/    Tablas limpias que importa Power BI
  database/          Base SQLite física, lista para consultar
  sql/               Esquema y consultas SQL legibles
  src/               Programas Python que regeneran los resultados
  notebooks/         Exploración explicada, con código y salidas
  powerbi/           Informe y modelo semántico; conservar la carpeta completa
  analysis/          Métricas, controles, segmentos, candidatos y escenarios
  reports/           Resumen ejecutivo en PDF
  images/            Imágenes del resumen editorial para presentar el caso
  docs/              Metodología, fuentes, diccionario y plan
  tests/             Pruebas de datos, SQL y estructura del informe
  config/            Supuestos y umbrales explícitos del piloto
```

### Reproducir

Requiere Python 3.10 o superior. Desde la carpeta de este proyecto:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe src/run_project.py
```

La ejecución usa la copia local de la fuente; no descarga ni publica datos. Regenera la base, los resultados, el notebook, el PDF y el PBIP. **Antes de regenerar Power BI, cerrar Desktop y respaldar las ediciones manuales**: el generador escribe los archivos del informe. Para conservarlo:

```powershell
.\.venv\Scripts\python.exe src/run_project.py --skip-powerbi
```

Las imágenes PNG son exportaciones del PDF. No se regeneran con este comando; se pueden volver a exportar con Poppler (`pdftoppm -r 90 -png`). Los controles locales no sustituyen la actualización y revisión visual en Power BI Desktop. Ver [checklist de Power BI](docs/abrir_powerbi.md).

### Calidad y decisiones de análisis

- `customerID` es único incluso sin distinguir mayúsculas. Es la clave primaria, no un número.
- Los 11 `TotalCharges` vacíos pertenecen a clientes con `tenure=0`. Se conservan como nulos; no se imputan ceros.
- Se conservan `No internet service` y `No phone service` como categorías estructurales.
- Los importes se concilian mediante centavos enteros.
- Los segmentos son excluyentes; no se suman grupos solapados.
- El listado de candidatos contiene solo clientes activos de la muestra; no predice su abandono.
- Los escenarios de 1, 3 y 5 puntos porcentuales son supuestos ilustrativos frente a un control, no mejoras conseguidas.

### Fuente y alcance

Archivo utilizado: `Telco-Customer-Churn.csv`, idéntico byte a byte al [CSV público de IBM](https://github.com/IBM/telco-customer-churn-on-icp4d/blob/master/data/Telco-Customer-Churn.csv), comprobado el 14 de septiembre de 2026. Se conserva el CSV sin modificar, junto con la atribución y la licencia del repositorio fuente. Ver [fuentes](docs/fuentes.md) y [verificación](analysis/publication_source_verification.json).

No es un encargo de un cliente real ni un caso con retorno comercial demostrado. Desarrollado con asistencia de IA; las decisiones y limitaciones están documentadas. La revisión nativa de Power BI sigue pendiente.

### Configurar Power BI después de descargar

La copia pública usa `C:/TELCO_RETAIN/data/processed` como ruta de ejemplo, no una carpeta de tu equipo. Desde la raíz extraída, ejecuta:

```powershell
python src/configure_data.py --folder "RUTA/telco-retention-analytics/data/processed"
```

También puedes cambiar `DataFolder` desde Power BI siguiendo [la guía](docs/abrir_powerbi.md). Este paso no actualiza ni valida el modelo nativo; solo configura la ubicación de los dos CSV. Los datos, SQLite y el informe completo están incluidos en esta carpeta.
