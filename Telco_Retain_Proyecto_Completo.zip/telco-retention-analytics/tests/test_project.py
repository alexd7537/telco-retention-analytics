"""Controles locales sin Power BI Desktop. Ejecutar: python -m unittest discover -s tests -v"""
from pathlib import Path
import json
import sqlite3
import sys
import unittest
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from analyze import clean, cents, assign_segment

class ProjectTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw=pd.read_csv(ROOT/'data/raw/Telco-Customer-Churn.csv',dtype=str,keep_default_na=False)
        cls.d=clean(cls.raw)
        cls.conn=sqlite3.connect((ROOT/'database/telco_retention.sqlite').as_uri()+'?mode=ro',uri=True)
    @classmethod
    def tearDownClass(cls):cls.conn.close()
    def test_snapshot(self):
        self.assertEqual(self.raw.shape,(7043,21))
        self.assertEqual(int(self.d.ChurnFlag.sum()),1869)
        self.assertEqual(len(self.d),len(self.raw))
    def test_identity_preserved(self):
        self.assertEqual(self.d.customerID.tolist(),self.raw.customerID.tolist())
        self.assertTrue(self.d.customerID.str.upper().is_unique)
    def test_totals_missing_are_not_zero(self):
        self.assertEqual(int(self.d.TotalCharges.isna().sum()),11)
        self.assertEqual(int(self.d.TotalChargesCents.isna().sum()),11)
        self.assertTrue(self.d.loc[self.d.TotalCharges.isna(),'tenure'].eq(0).all())
    def test_exact_money(self):
        self.assertEqual(cents('29.85'),2985)
        self.assertIsNone(cents('  ',True))
        for bad in ['-1','1.001','oops','NaN','Infinity','']:
            with self.subTest(bad=bad),self.assertRaises(ValueError):cents(bad)
    def test_duplicate_and_empty_rejected(self):
        for value in [self.raw.customerID.iloc[0].lower(),' ']:
            bad=self.raw.iloc[:2].copy();bad.loc[bad.index[1],'customerID']=value
            with self.assertRaises(ValueError):clean(bad)
    def test_unknown_category_rejected(self):
        bad=self.raw.iloc[:2].copy();bad.loc[0,'Churn']='Unknown'
        with self.assertRaises(ValueError):clean(bad)
    def test_structural_services(self):
        self.assertTrue(self.d.TechSupport.eq('No internet service').equals(self.d.InternetService.eq('No')))
        self.assertTrue(self.d.ServiceCount.between(0,9).all())
    def test_segment_boundaries(self):
        base={'Contract':'Month-to-month','tenure':6,'InternetService':'Fiber optic','TechSupport':'No','MonthlyChargesCents':9000}
        self.assertEqual(assign_segment(base),'S1')
        self.assertEqual(assign_segment(dict(base,tenure=7)),'S2')
        self.assertEqual(assign_segment(dict(base,tenure=7,TechSupport='Yes',MonthlyChargesCents=8000)),'S3')
        self.assertEqual(assign_segment(dict(base,tenure=7,TechSupport='Yes',MonthlyChargesCents=7999)),'S4')
        self.assertEqual(assign_segment(dict(base,Contract='One year')),'S5')
        self.assertEqual(assign_segment(dict(base,Contract='Two year')),'S6')
    def test_band_boundaries(self):
        for tenure,order in [(0,1),(6,1),(7,2),(12,2),(13,3),(24,3),(25,4),(48,4),(49,5),(72,5)]:
            frame=self.raw.iloc[:1].copy();frame.loc[0,'tenure']=str(tenure)
            self.assertEqual(clean(frame).TenureBandOrder.iloc[0],order)
        for value,order in [('34.99',1),('35',2),('79.99',2),('80',3)]:
            frame=self.raw.iloc[:1].copy();frame.loc[0,'MonthlyCharges']=value
            self.assertEqual(clean(frame).ChargeBandOrder.iloc[0],order)
    def test_sql_constraints_and_integrity(self):
        self.assertEqual(self.conn.execute('PRAGMA integrity_check').fetchone()[0],'ok')
        table=self.conn.execute('PRAGMA table_info(customers)').fetchall()
        self.assertEqual(next(r for r in table if r[1]=='customerID')[5],1)
        self.assertEqual(self.conn.execute('SELECT COUNT(*) FROM customers').fetchone()[0],len(self.d))
    def test_sql_python_reconcile(self):
        row=self.conn.execute('SELECT SUM(ChurnFlag), SUM(CASE WHEN ChurnFlag=1 THEN MonthlyChargesCents ELSE 0 END) FROM customers').fetchone()
        self.assertEqual(row,(1869,13913085))
        grouped=pd.read_sql_query('SELECT Contract, COUNT(*) Customers, SUM(ChurnFlag) Churned FROM customers GROUP BY Contract',self.conn).set_index('Contract')
        for name,frame in self.d.groupby('Contract'):
            self.assertEqual(grouped.loc[name,'Customers'],len(frame))
            self.assertEqual(grouped.loc[name,'Churned'],frame.ChurnFlag.sum())
    def test_support_denominator(self):
        table=pd.read_csv(ROOT/'analysis/sql_results/04_factors.csv')
        support=table[table.Factor.eq('Soporte (solo internet)')]
        self.assertEqual(int(support.Customers.sum()),int(self.d.InternetService.ne('No').sum()))
        self.assertNotIn('No aplica',set(support.Category))
    def test_segment_reconciliation(self):
        segments=pd.read_csv(ROOT/'analysis/priority_segments.csv')
        self.assertEqual(int(segments.Customers.sum()),len(self.d))
        self.assertEqual(int(segments.Active.sum()),5174)
        self.assertEqual(int(segments.Churned.sum()),1869)
        self.assertTrue(segments.SegmentID.is_unique)
    def test_candidates(self):
        candidates=pd.read_csv(ROOT/'analysis/pilot_candidates.csv')
        self.assertEqual(len(candidates),1442)
        self.assertTrue(candidates.customerID.is_unique)
        self.assertTrue(set(candidates.customerID).issubset(set(self.d.loc[self.d.ChurnFlag.eq(0),'customerID'])))
        self.assertNotIn('gender',candidates.columns)
        self.assertNotIn('SeniorCitizen',candidates.columns)
    def test_scenarios_formula(self):
        d=pd.read_csv(ROOT/'analysis/scenarios.csv')
        expected=d.Targets*d.AssumedIncrementalRetention*d.AvgMonthlyChargeActive
        self.assertTrue((expected-d.IllustrativeGrossMonthlyCharges).abs().lt(.0001).all())
        self.assertTrue((d.IllustrativeGrossMonthlyCharges-d.IllustrativeContactCost-d.GrossLessContactCostOnly).abs().lt(.0001).all())
    def test_powerbi_references_and_layout(self):
        model=json.loads((ROOT/'powerbi/TelcoRetention.SemanticModel/model.bim').read_text(encoding='utf-8'))['model']
        tables={t['name']:{c['name'] for c in t['columns']} | {m['name'] for m in t.get('measures',[])} for t in model['tables']}
        root=ROOT/'powerbi/TelcoRetention.Report/definition'
        pages=json.loads((root/'pages/pages.json').read_text(encoding='utf-8'))['pageOrder']
        self.assertEqual(len(pages),3)
        self.assertEqual(len(model['relationships']),1)
        roles={'cardVisual':{'Data'},'barChart':{'Category','Y','Tooltips'},'columnChart':{'Category','Y','Tooltips'},'slicer':{'Values'},'tableEx':{'Values'}}
        names=set()
        for path in root.glob('pages/*/visuals/*/visual.json'):
            v=json.loads(path.read_text(encoding='utf-8'));p=v['position'];visual=v['visual']
            self.assertNotIn(v['name'],names); names.add(v['name'])
            self.assertGreaterEqual(p['x'],0);self.assertGreaterEqual(p['y'],0)
            self.assertLessEqual(p['x']+p['width'],1440);self.assertLessEqual(p['y']+p['height'],900)
            query=visual.get('query',{}).get('queryState',{})
            if query:self.assertEqual(set(query),roles[visual['visualType']])
            for role in query.values():
                for pr in role['projections']:
                    f=next(iter(pr['field'].values()))
                    self.assertIn(f['Property'],tables[f['Expression']['SourceRef']['Entity']])
            if visual['visualType']=='actionButton':
                raw=visual['visualContainerObjects']['visualLink'][0]['properties']['navigationSection']['expr']['Literal']['Value']
                self.assertIn(raw.strip("'"),pages)
        self.assertEqual(len(names),69)
    def test_editorial_navigation(self):
        report=ROOT/'powerbi/TelcoRetention.Report/definition'
        for page in ['Panorama','Factores','Prioridades']:
            visuals=[json.loads(p.read_text(encoding='utf-8')) for p in (report/f'pages/{page}/visuals').glob('*/visual.json')]
            buttons=[v for v in visuals if v['visual']['visualType']=='actionButton']
            self.assertEqual(len(buttons),3)
            self.assertEqual(len({v['position']['y'] for v in buttons}),1)
            self.assertTrue(all(v['position']['y']+v['position']['height']<=72 for v in buttons))
            self.assertFalse(any(v['position']['x']==0 and v['position']['width']==202 and v['position']['height']==900 for v in visuals))
    def test_editorial_palette(self):
        theme=json.loads((ROOT/'powerbi/TelcoRetention.Report/StaticResources/RegisteredResources/TelcoRetain.json').read_text(encoding='utf-8'))
        self.assertEqual(theme['dataColors'][0],'#6A43C2')
        self.assertEqual(theme['foreground'],'#251B36')
        values=json.dumps(theme)
        for old in ['#087E83','#D86C53','#152C40']:
            self.assertNotIn(old,values)
    def test_powerbi_import_null_and_types(self):
        model=json.loads((ROOT/'powerbi/TelcoRetention.SemanticModel/model.bim').read_text(encoding='utf-8'))['model']
        customers=next(t for t in model['tables'] if t['name']=='Customers')
        expr='\n'.join(customers['partitions'][0]['source']['expression'])
        self.assertIn('Replacer.ReplaceValue',expr)
        self.assertIn('"en-US"',expr)
        segments=pd.read_csv(ROOT/'data/processed/Segments.csv')
        self.assertTrue(segments.SegmentID.str.upper().is_unique)
        self.assertTrue(set(self.d.SegmentID).issubset(set(segments.SegmentID)))
    def test_notebook_executed(self):
        notebook=json.loads((ROOT/'notebooks/01_exploracion.ipynb').read_text(encoding='utf-8'))
        code=[c for c in notebook['cells'] if c['cell_type']=='code']
        self.assertEqual([c['execution_count'] for c in code],list(range(1,len(code)+1)))
        self.assertFalse(any(o['output_type']=='error' for c in code for o in c['outputs']))

if __name__=='__main__':unittest.main()
