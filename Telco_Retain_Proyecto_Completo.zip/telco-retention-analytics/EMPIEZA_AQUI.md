# Proyecto 2: por dónde empezar

Ya tienes una primera versión descriptiva del caso **TELCO / RETAIN**. No necesitas instalar un servidor de bases de datos para ver los resultados.

## 1. Mira el resultado antes de abrir el código

Abre `reports/Resumen_ejecutivo_retencion.pdf`. Explica en cinco páginas:

1. Cuántos clientes abandonaron, cómo cambia la tasa por contrato y el foco de clientes mensuales nuevos.
2. Qué factores se relacionan con el abandono, sin confundir relación con causa.
3. A qué segmentos prestar atención y qué acciones probar.
4. Cómo medir un piloto y cómo interpretar los escenarios.
5. Qué se validó y qué limitaciones tiene la base.

Las imágenes de `images/` vienen de este PDF. **No son capturas de Power BI.**

## 2. Abre Power BI

Abre `powerbi/TelcoRetention.pbip`, no `model.bim` ni los JSON sueltos. El archivo PBIP necesita las carpetas `TelcoRetention.Report` y `TelcoRetention.SemanticModel` que están a su lado.

El informe está preparado con tres páginas, navegación horizontal y filtros de contrato, antigüedad y segmento. La tasa ocupa el foco de Panorama; los cargos y la antigüedad media aparecen en la tabla de detalle. Sus cifras deben comprobarse al actualizar. Sigue `docs/abrir_powerbi.md`; la carga nativa, las medidas DAX y el aspecto final en Desktop todavía no están verificados.

El informe lee los CSV de `data/processed/`. **No lee directamente SQLite**: ambos usan la misma limpieza, y SQL sirve para auditar las cifras sin necesitar un conector SQLite/ODBC en Power BI.

## 3. Encuentra la base de datos real

La base creada es `database/telco_retention.sqlite`. Es un archivo SQLite, no una carpeta ni una hoja de cálculo. Contiene:

- `customers`: los 7.043 clientes limpios, clave primaria `customerID` y campos derivados.
- `segments`: los seis grupos, sus métricas, reglas y prioridad.

Puedes abrirla con una herramienta compatible con SQLite. Los archivos `.sql` de `sql/` son instrucciones de consulta; **no son la base de datos**.

## 4. Entiende el Python

Empieza por `notebooks/01_exploracion.ipynb`, que combina explicación, código y resultados. También tienes una versión de texto, `notebooks/01_exploracion.py`, que se puede leer sin Jupyter.

Después revisa:

| Archivo | Responsabilidad |
|---|---|
| `src/analyze.py` | Valida, limpia, crea SQLite y ejecuta SQL |
| `src/build_powerbi.py` | Genera modelo, medidas y páginas nativas del PBIP |
| `src/design_editorial.py` | Define la nueva paleta, navegación y distribución de los visuales |
| `src/build_report.py` | Genera el PDF con resultados calculados |
| `src/build_notebook.py` | Construye el notebook y ejecuta sus celdas en Python |
| `src/run_project.py` | Ejecuta el flujo y las pruebas |

No hace falta ejecutarlos para abrir el PDF o leer las consultas. Si vas a regenerar archivos, consulta primero las instrucciones del README.

## 5. No confundas las ubicaciones

La fuente se conserva sin modificaciones en `data/raw/Telco-Customer-Churn.csv`. La copia coincide con el CSV público de IBM, según la verificación documentada en `docs/fuentes.md`.

La carpeta principal de esta entrega es `telco-retention-analytics`, creada al extraer el ZIP completo. Todo lo necesario para trasladar el proyecto está dentro de ella; no depende del proyecto de ventas.

No se incluyen cachés, entornos virtuales ni archivos temporales. La estructura interna del ZIP es la versión ejecutable; los archivos sueltos de GitHub son una selección para consultar el trabajo en el navegador.

**No muevas una sola pieza de `powerbi/`.** Si decides cambiar de ubicación, mueve o copia la carpeta completa del proyecto y cambia el parámetro `DataFolder` al nuevo `data/processed/`.

## 6. Cómo explicarlo en una entrevista

“Analicé una muestra de clientes Telco para localizar segmentos con alta concentración de abandono. Construí una limpieza reproducible en Python, una base SQLite con consultas auditables y un informe Power BI. Separé los patrones observados de las hipótesis de retención y propuse un piloto con grupo de control.”

No digas que redujiste el abandono o recuperaste ingresos: todavía no se ha ejecutado un experimento. Para poder defender el caso, debes poder explicar el denominador de la tasa, los 11 nulos, los segmentos y por qué una asociación no prueba una causa.

## Siguiente paso

Configurar `DataFolder` y validar la actualización y las tres páginas en Power BI Desktop con el checklist de `docs/abrir_powerbi.md`. El archivo PBIP se entrega como prototipo editable con esa revisión pendiente.
